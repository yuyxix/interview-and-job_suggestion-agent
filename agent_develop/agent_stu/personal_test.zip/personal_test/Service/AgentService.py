import selectors

from model.my_model import MyModel
from personal_test.Tools.SendEmailTool import send_email
# from prompt.builder_prompt_yaml import BuilderPromptYaml
from langchain.agents import create_agent
from langchain_core.messages import HumanMessage
import asyncio
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
import os
from dotenv import load_dotenv
from langchain.agents.middleware import SummarizationMiddleware
load_dotenv()


async def personal_agent(question, user_id):
    # 加载模型
    model = MyModel.get_local_model()
    # 设置工具
    tools = [send_email]
    # 设置提示词
    prompt = """
        根据用户的要求做对应的回答或执行相应的任务
        当问题没有明确提及完成某个任务时，正常回答用户问题即可
        
    """
    summary_prompt = """
        任务:
            总结用户的对话，生成摘要，其中涉及用户信息的对话需要重点摘要
        规则:
            以第三人称的方式书写
        历史对话
            {messages}
    """
    memory_url = os.getenv('POSTGRESQL_URL')
    # 定义中间键
    summary = SummarizationMiddleware(
        model=model,
        trigger=('tokens', 30),
        keep=('messages', 3),
        summary_prompt=summary_prompt,
        trim_tokens_to_summarize=4000
    )
    # 创建智能体
    # 在异步函数中，有专门封装异步版的postgresaver
    async with AsyncPostgresSaver.from_conn_string(memory_url) as pg:
        # await pg.setup()
        agent = create_agent(
            model=model,
            tools=tools,
            system_prompt=prompt,
            middleware=[summary],
            checkpointer=pg
        )
        # 定义消息格式
        human_msg = {
            'messages': [
                HumanMessage(content=question)
            ]
        }
        config = {'configurable': {'thread_id': user_id}}
        # 获取结果
        rs = agent.astream_events(human_msg, config, verson='v2')
        async for event in rs:
            event_name = event['event']
            if event_name == 'on_chain_start':
                yield '\n正在理解用户意图...\n'
            elif event_name == 'on_chain_stream':
                yield '\n正在执行任务...\n'
                data = event['data']['chunk']
                if data:
                    if 'tools' in data:
                        content = data['tools']['messages'][0].content
                        if content:
                            yield content
                    elif 'model' in data:
                        content = data['model']['messages'][0].content
                        if content:
                            yield content


async def output(query, user_id):
    async for rs in personal_agent(query, user_id):
        print(rs, end='')
    return '执行成功'

if __name__ == '__main__':
    question1 = '通知cyx，明天上午来上课'
    question2 = '你好，我是cyx'
    question3 = '帮我写一个100字的数学加法课程 大纲'
    question4 = '请把课程大纲发送到我的邮箱里'
    # 当函数是个异步函数，就要用异步库中的函数来执行函数，即 asyncio.run()
    # 和postgresql建立连接要走I/O网络等待机制，Windows默认的实现机制和这个不兼容，所以需要指定一个兼容的实现机制
    asyncio.run(
        # output(question1, 1),
        # output(question2, 1),
        # output(question3, 1),
        output(question4, 1),
        loop_factory=lambda: asyncio.SelectorEventLoop(selectors.SelectSelector()),
    )


