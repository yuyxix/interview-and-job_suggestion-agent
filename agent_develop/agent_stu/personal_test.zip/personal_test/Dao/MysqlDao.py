from personal_test.Util.MySqlUtil import GetMysqlCon


def get_user_info(username):
    con = GetMysqlCon.get_mysql_con()
    cur = con.cursor()
    try:
        sql = 'SELECT * FROM `agent_userinfo` WHERE user_name = %s'
        cur.execute(sql, [username])
        result = cur.fetchall()
        return result
    except Exception as e:
        print(f'数据查询失败:{e}')
        return None
    finally:
        GetMysqlCon.close_mysql_con(cur, con)

if __name__ == '__main__':
    print(get_user_info('cyx'))
