import pymysql
import os
from dotenv import load_dotenv

load_dotenv()


class GetMysqlCon:
    _host = os.getenv("MYSQL_HOST")
    _port = os.getenv("MYSQL_PORT")
    _user = os.getenv("MYSQL_USER")
    _password = os.getenv("MYSQL_PASSWORD")
    _db = os.getenv("MYSQL_DB")
    _charset = os.getenv("MYSQL_CHARSET")

    @staticmethod
    def get_mysql_con():
        return pymysql.connect(
            host=GetMysqlCon._host,
            port=int(GetMysqlCon._port),
            user=GetMysqlCon._user,
            password=GetMysqlCon._password,
            db=GetMysqlCon._db,
            charset=GetMysqlCon._charset,
            cursorclass=pymysql.cursors.DictCursor
        )

    @staticmethod
    def close_mysql_con(cursor, con):
        cursor.close()
        con.close()

